from django.contrib import admin

from .models import Prediction

admin.site.register(Prediction)